﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure; // Namespace for CloudConfigurationManager
using Microsoft.WindowsAzure.Storage; // Namespace for CloudStorageAccount
using Microsoft.WindowsAzure.Storage.Queue; // Namespace for Queue storage types

namespace Queue_Storage_App_New
{
    class Program
    {
        static void Main(string[] args)
        {
            QueueOperations queue = new QueueOperations();
            queue.CreateQueue();
        queue.AddMessage("My Name is Mahesh");
          queue.ReadMessage();
            queue.DeleteMessage();
            //queue.DeleteQueue();
            Console.ReadLine();
        }
    }

    public class QueueOperations
    {
        private CloudStorageAccount storageAccount;
        private CloudQueueClient queueClient;
        private CloudQueue queue;

        public QueueOperations()
        {
            // Parse the connection string and return a reference to the storage account.
            storageAccount = CloudStorageAccount.Parse(
               CloudConfigurationManager.GetSetting("StorageConnectionString"));
            queueClient = storageAccount.CreateCloudQueueClient();
            // Retrieve a reference to a container.
            queue = queueClient.GetQueueReference("myqueue");
        }

        public void CreateQueue()
        {
            // Create the queue if it doesn't already exist
            queue.CreateIfNotExists();
        }
        public void AddMessage(string data)
        {
            // Create a message and add it to the queue.
            CloudQueueMessage message = new CloudQueueMessage(data);
            Console.WriteLine(CloudQueueMessage.MaxMessageSize);
            Console.WriteLine(CloudQueueMessage.MaxNumberOfMessagesToPeek);
            Console.WriteLine(CloudQueueMessage.MaxTimeToLive);


            queue.AddMessage(message);
        }

        public void ReadMessage()
        {
            // Peek at the next message
            CloudQueueMessage peekedMessage = queue.PeekMessage();

            // Display message.
            Console.WriteLine(peekedMessage.AsString);
        }

        public void DeleteMessage()
        {
            // Get the next message
            CloudQueueMessage retrievedMessage = queue.GetMessage();

            //Process the message in less than 30 seconds, and then delete the message
            queue.DeleteMessage(retrievedMessage);
        }

        public void DeleteQueue()
        {
            // Retrieve a reference to a queue.
            CloudQueue queue = queueClient.GetQueueReference("myqueue");

            // Delete the queue.
            queue.Delete();
        }

    }


}
